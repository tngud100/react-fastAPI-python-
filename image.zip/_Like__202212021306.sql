INSERT INTO jaylog.`Like` (post_idx,user_idx,create_date,update_date,delete_date) VALUES
	 (8,2,'2022-12-02 13:04:27',NULL,NULL),
	 (7,2,'2022-12-02 13:04:27',NULL,NULL),
	 (6,2,'2022-12-02 13:04:27',NULL,NULL),
	 (5,2,'2022-12-02 13:04:27',NULL,NULL);
